export interface UserReviewItem {
  bookId: string
  userId: string
  createdAt: string
  reviewRate: number
}
