export interface UpdateBook {
  name: string
  author: string
  releaseDate: string
  obtained: boolean
}
