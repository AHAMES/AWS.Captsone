export interface AuthorItem {
  name: string
  authorId: string
  createdAt: string
  attachmentUrl?: string
}
