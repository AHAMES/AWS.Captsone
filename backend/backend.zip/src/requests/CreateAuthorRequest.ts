export interface CreateAuthorRequest {
  name: string
}
