export interface CreateUserReviewRequest {
  bookId: string
  reviewRate: number
}
