export interface UpdateAuthorRequest {
  name: string
}
